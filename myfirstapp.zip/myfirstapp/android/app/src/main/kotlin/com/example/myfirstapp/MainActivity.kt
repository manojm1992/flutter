package com.example.myfirstapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
